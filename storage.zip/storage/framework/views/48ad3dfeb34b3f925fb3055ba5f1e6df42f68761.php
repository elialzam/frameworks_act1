
<?php $__env->startSection('content'); ?>
<h1>Formulario</h1>

<form method="POST" action="<?php echo e(route('crear.producto')); ?>" role="form">
    <?php echo e(csrf_field()); ?>

  <div class="form-group">
    <label for="exampleInputEmail1">Nombre del producto</label>
    <input type="text" class="form-control" id="name" name="name" aria-describedby="emailHelp" placeholder="Nombre">
  </div>
  <div class="form-group">
    <label for="exampleInputPassword1">Descripción del producto</label>
    <input type="text" class="form-control" id="description" name="description" placeholder="Descripción">
  </div>
  <div class="form-group">
    <label for="exampleInputPassword1">Precio del producto</label>
    <input type="number" class="form-control" id="price" name="price" placeholder="Precio">
  </div>
  <button type="submit" class="btn btn-primary">Guardar producto</button>
</form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\example-app\resources\views/crud.blade.php ENDPATH**/ ?>