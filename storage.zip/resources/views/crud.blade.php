@extends('layouts.app')
@section('content')
<h1>Formulario</h1>

<form method="POST" action="{{route('crear.producto')}}" role="form">
    {{csrf_field()}}
  <div class="form-group">
    <label for="exampleInputEmail1">Nombre del producto</label>
    <input type="text" class="form-control" id="name" name="name" aria-describedby="emailHelp" placeholder="Nombre">
  </div>
  <div class="form-group">
    <label for="exampleInputPassword1">Descripción del producto</label>
    <input type="text" class="form-control" id="description" name="description" placeholder="Descripción">
  </div>
  <div class="form-group">
    <label for="exampleInputPassword1">Precio del producto</label>
    <input type="number" class="form-control" id="price" name="price" placeholder="Precio">
  </div>
  <button type="submit" class="btn btn-primary">Guardar producto</button>
</form>

@endsection