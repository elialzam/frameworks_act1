@extends('layouts.app')
@section('content')
    <h1>este es el producto</h1>
    <table class="table">
  <thead>
    <tr>
      <th scope="col">Nombre</th>
      <th scope="col">Descripción</th>
      <th scope="col">Precio</th>
    </tr>
  </thead>
  <tbody>
      @foreach($products as $producto)
    <tr>
        <td>{{$producto['name']}}</td>
        <td>{{$producto['description']}}</td>
        <td>{{$producto['price']}}</td>
    </tr>
    @endforeach
  </tbody>
</table>
@endsection